
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let drone = { x: 200, y: 0, size: 40, speed: 2 };
let score = 0;

function drawDrone() {
  ctx.fillStyle = "black";
  ctx.fillRect(drone.x - 20, drone.y - 20, drone.size, drone.size);
}

function updateGame() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drone.y += drone.speed;

  if (drone.y > canvas.height) {
    drone.y = 0;
    drone.x = Math.random() * (canvas.width - drone.size);
  }

  drawDrone();
  requestAnimationFrame(updateGame);
}

canvas.addEventListener("click", function (e) {
  const rect = canvas.getBoundingClientRect();
  const clickX = e.clientX - rect.left;
  const clickY = e.clientY - rect.top;

  if (
    clickX >= drone.x - 20 &&
    clickX <= drone.x + 20 &&
    clickY >= drone.y - 20 &&
    clickY <= drone.y + 20
  ) {
    score++;
    document.getElementById("score").innerText = score;
    drone.y = 0;
    drone.x = Math.random() * (canvas.width - drone.size);
  }
});

updateGame();
